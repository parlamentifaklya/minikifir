﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniKIFIR
{
    public interface IFelvetelizo
    {

        String OmAzon { get; set; }
        String Nev { get; set; }
        String ErtesitesiCime { get; set; }
        String Email { get; set; }
        DateTime SzuletesiDatum { get; set; }
        int MatekPont { get; set; }
        int MagyarPont { get; set; }

        String CSVSortAdVissza();

        void ModositCSVSorral(String csvString);
    }
}
