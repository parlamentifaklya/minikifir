﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniKIFIR
{
    public class Feltoltes
    {
        string omAzon;
        string nev;
        string ertesitesiCime;
        string email;
        DateTime szuletesiDatum;
        int matek;
        int magyar;

        public Feltoltes(string line)
        {
            List<string> elem = line.Split(';').ToList();
            this.omAzon = elem[0];
            this.nev = elem[1];
            this.ertesitesiCime = elem[2];
            this.email = elem[4];
            this.szuletesiDatum = Convert.ToDateTime(elem[3]);
            try
            {
                this.matek = Convert.ToInt32(elem[5]);
            } catch {
                this.matek = -1;
            }
            try
            {
                this.magyar = Convert.ToInt32(elem[6]);
            } catch
            {
                this.magyar = -1;
            }
        }

        public string OmAzon { get => omAzon; set => omAzon = value; }
        public string Nev { get => nev; set => nev = value; }
        public string ErtesitesiCime { get => ertesitesiCime; set => ertesitesiCime = value; }
        public string Email { get => email; set => email = value; }
        public DateTime SzuletesiDatum { get => szuletesiDatum; set => szuletesiDatum = value; }
        public int Matek { get => matek; set => matek = value; }
        public int Magyar { get => magyar; set => magyar = value; }

        public void ModositCSVSorral(string csvString) { }
    }
}
