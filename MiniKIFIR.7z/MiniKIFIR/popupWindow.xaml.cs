﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MiniKIFIR
{
    /// <summary>
    /// Interaction logic for popupWindow.xaml
    /// </summary>
    public partial class popupWindow : Window
    {
        Felvetelizo _diak;
        public popupWindow()
        {
            InitializeComponent();
        }

        public popupWindow(Felvetelizo ujdiak) : this()
        {
            this._diak= ujdiak;
            this.Title = $"{_diak.Nev} adatainak rögzítése";
            txtNeve.Text = _diak.Nev;
        }

        private void btnFelvetel_Click(object sender, RoutedEventArgs e)
        {

            if(txtOm.Text == "" || txtOm.Text.Length != 11 || !(txtOm.Text.All(char.IsDigit)))
            {
                MessageBox.Show("Nem lehet üresen hagyni / Hibás OM azonosító");
                return;
            }
            else{
                _diak.OmAzon = txtOm.Text;
            }


            if (txtNeve.Text == "")
            {
                MessageBox.Show("Nem lehet üresen hagyni");
                return;

            }
            else
            {
                _diak.Nev = txtNeve.Text;
            }


            if (txtErtesitesiCim.Text == "")
            {
                MessageBox.Show("Nem lehet üresen hagyni");
                return;
            }
            else
            {
                _diak.ErtesitesiCime = txtErtesitesiCim.Text;
            }



            if (txtEmail.Text == "" || !(txtEmail.Text.Contains("@")))
            {
                MessageBox.Show("Nem lehet üresen hagyni / hibás email");
                return;
            }
            else
            {
                _diak.Email = txtEmail.Text;
            }


            _diak.SzuletesiDatum = Convert.ToDateTime(txtSzuletsiDatum.Text);
            try
            {
                this._diak.MatekPont = int.Parse(txtMatek.Text);
            } catch (Exception)
            {
                MessageBox.Show("Nem szám");
                return;
            }
            try
            {
                this._diak.MagyarPont = int.Parse(txtMagyar.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Nem szám");
                return;
            }
            if (_diak.MatekPont < 0 || _diak.MagyarPont < 0 || _diak.MatekPont > 50 || _diak.MagyarPont > 50)
            {
                MessageBox.Show("Nem lehet ennyi pontja");
                return;
            }
            Close();
        }
    }
}