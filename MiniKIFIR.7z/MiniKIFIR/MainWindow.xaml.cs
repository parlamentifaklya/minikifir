﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.Json;
using System.Text.Encodings.Web;
using MySql;
using MySql.Data.MySqlClient;

namespace MiniKIFIR
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<IFelvetelizo> diakok = new ObservableCollection<IFelvetelizo>();
        public MainWindow()
        {
            loadFromDB();
            InitializeComponent();
            //List<Felvetelizo> adatok = new List<Felvetelizo>();
            //CSVDatagrid.ItemsSource = diakok;

            using (StreamReader reader = new StreamReader("felvetelizok.csv"))
            {
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    Felvetelizo diak = new Felvetelizo(line);
                    diakok.Add(diak);
                }

            }
            CSVDatagrid.ItemsSource = diakok;
        }

        private void loadFromDB()
        {
            List<string> diakDB = new List<string>();
            string connstr = "Server=localhost;Uid=root;Pwd=;database=minikifir";
            var conn = new MySqlConnection(connstr);
            conn.Open();
            var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM diakok";
            var reader = cmd.ExecuteReader();
            int index = 0;
            while (reader.Read())
            {
                diakDB.Add(reader.GetString(index));
                index++;
            }
            conn.Close();
        }


        private void Torles_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var selectedItems = CSVDatagrid.SelectedItems;
                if (selectedItems.Count > 0)
                {
                    List<Object> itemsToRemove = new List<Object>();
                    foreach (var item in selectedItems)
                    {
                        itemsToRemove.Add(item);
                    }

                    foreach (var item in itemsToRemove)
                    {
                        diakok.Remove(item as Felvetelizo);
                    }
                }
            }
            catch
            {
                MessageBox.Show("Hiba a törlés során");
            }
        }

        private void Import_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "CSV File (*.csv)|*.csv|JSON File (*.json)|*.json";
            openFileDialog.FilterIndex = 1;

            bool? result = openFileDialog.ShowDialog();

            if (result == true)
            {
                string fileName = openFileDialog.FileName;

                if (fileName.Contains(".csv"))
                {
                    using (StreamReader reader = new StreamReader(fileName))
                    {
                        while (!reader.EndOfStream)
                        {
                            string line = reader.ReadLine();
                            Felvetelizo importedDiak = new Felvetelizo(line);
                            diakok.Add(importedDiak);
                        }

                    }
                }
                else
                {
                    string jsonString = File.ReadAllText(fileName);
                    var options = new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    };
                    List<Felvetelizo> importData = JsonSerializer.Deserialize<List<Felvetelizo>>(jsonString, options);
                    if (importData != null)
                    {
                        foreach (var adat in importData)
                        {
                            diakok.Add(adat);
                        }
                    }
                }
            }
        }

        private void UjDiak_Click(object sender, RoutedEventArgs e)
        {
            Felvetelizo uj = new Felvetelizo();
            popupWindow ujablak = new popupWindow(uj);
            ujablak.ShowDialog();
            diakok.Add(uj);
        }

        private void Export_Click(object sender, RoutedEventArgs e)
        {
            var options = new JsonSerializerOptions();
            options.Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
            options.WriteIndented = true;

            string dataLine = JsonSerializer.Serialize(diakok, options);

            var list = new List<String>();
            list.Add(dataLine);
            File.WriteAllLines("export.json", list);
            MessageBox.Show("Siker!");
        }
    }
}