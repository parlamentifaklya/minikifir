﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql;
using MySql.Data.MySqlClient;

namespace MiniKIFIR
{
    public class Felvetelizo : IFelvetelizo
    {

        string omAzon;
        string nev;
        string ertesitesiCime;
        string email;
        DateTime szuletesiDatum;
        int matek;
        int magyar;

        public Felvetelizo()
        {

        }

        public Felvetelizo(string line)
        {
            List<string> elem = line.Split(';').ToList();
            this.omAzon = elem[0];
            this.nev = elem[1];
            this.ertesitesiCime = elem[2];
            this.email = elem[4];
            this.szuletesiDatum = Convert.ToDateTime(elem[3]);
            try
            {
                this.matek = Convert.ToInt32(elem[5]);
            }
            catch
            {
                this.matek = -1;
            }
            try
            {
                this.magyar = Convert.ToInt32(elem[6]);
            }
            catch
            {
                this.magyar = -1;

            }
        }

        public string OmAzon { get => this.omAzon; set => this.omAzon = value ; }
        public string Nev { get => this.nev ; set => this.nev = value ; }
        public string ErtesitesiCime { get => this.ertesitesiCime ; set => this.ertesitesiCime = value ; }
        public string Email { get => this.email ; set => this.email = value; }
        public DateTime SzuletesiDatum { get => this.szuletesiDatum; set => this.szuletesiDatum = value; }
        public int MatekPont { get => this.matek ; set => this.matek = value; }
        public int MagyarPont { get => this.magyar ; set => this.magyar = value ; }

        public string CSVSortAdVissza()
        {
            throw new NotImplementedException();
        }

        public void ModositCSVSorral(string csvString)
        {
            throw new NotImplementedException();
        }
    }
}
